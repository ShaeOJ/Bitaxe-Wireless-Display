#ifndef BITCOIN_LOGO_H
#define BITCOIN_LOGO_H

#include <lvgl.h>

extern const lv_image_dsc_t bitcoin_logo_16x16;

#endif /* BITCOIN_LOGO_H */