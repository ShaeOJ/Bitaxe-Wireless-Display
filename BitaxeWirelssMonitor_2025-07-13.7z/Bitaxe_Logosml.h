#ifndef BITAXE_LOGOSML_H
#define BITAXE_LOGOSML_H

#include <lvgl.h>

extern const lv_image_dsc_t BitAxe_Logosml;

#endif // BITAXE_LOGOSML_H